import Profile from "../components/Profile";

function Dashboard() {
    return (
        <div className="container">
            <br />
            <Profile />
        </div>
    )
}

export default Dashboard;