module.exports = {
    Stock: require("./stock")
};
